﻿Imports System.Globalization
Imports System.ComponentModel
Public Class Form1

    Dim nom_cognoms As String
    Dim curs As String
    Dim horari As String
    Dim validar_cb As Boolean
    Dim validar_rb As Boolean

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        cbCurs.Items.Add("1r")
        cbCurs.Items.Add("2n")
        cbCurs.Items.Add("3n")
        cbCurs.Items.Add("4n")
        tbNomCognoms.Focus()
        validar_cb = False
        validar_rb = False
        ComboBox1.Items.Add("English")
        ComboBox1.Items.Add("Italiano")
        ComboBox1.Items.Add("Català")
        ComboBox1.Items.Add("Español")
    End Sub
    Private Sub ChangeLanguage(ByVal Language As String)
        For Each c As Control In Me.Controls
            Dim crmLang As ComponentResourceManager = New ComponentResourceManager(GetType(Form1))
            crmLang.ApplyResources(c, c.Name, New CultureInfo(Language))
        Next c
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        nom_cognoms = tbNomCognoms.Text
        If (String.Compare(nom_cognoms.Trim, "") = 0) Then
            MessageBox.Show("[ERROR] Cal posar nom i cognoms")
        Else
            If (validar_cb) Then
                If (validar_rb) Then
                    If (ListBox1.Items.Contains(nom_cognoms) = True) Then
                        MessageBox.Show("[ERROR] L'alumne ja està registrat")
                    Else
                        ListBox1.Items.Add(nom_cognoms)
                        ListBox2.Items.Add(curs)
                        ListBox3.Items.Add(horari)
                        nom_cognoms = ""
                        curs = ""
                        horari = ""
                        cbCurs.Text = ""
                        tbNomCognoms.Clear()
                        rb0.Checked = False
                        rb1.Checked = False
                        validar_cb = False
                        validar_rb = False
                    End If
                Else
                    MessageBox.Show("[ERROR] Seleccionar horari")
                End If
            Else
                MessageBox.Show("[ERROR] Seleccionar curs")
            End If
        End If

    End Sub

    Private Sub rb0_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb0.CheckedChanged
        horari = "Matí"
        validar_rb = True

    End Sub

    Private Sub rb1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb1.CheckedChanged
        horari = "Tarda"
        validar_rb = True
    End Sub

    Private Sub cbCurs_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbCurs.SelectedIndexChanged
        curs = cbCurs.SelectedItem.ToString()
        validar_cb = True
    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        If ComboBox1.SelectedIndex = 0 Then
            ChangeLanguage("en")
        ElseIf ComboBox1.SelectedIndex = 1 Then
            ChangeLanguage("it-IT")
        ElseIf ComboBox1.SelectedIndex = 2 Then
            ChangeLanguage("ca-ES")
        Else
            ChangeLanguage("es-ES")
        End If
    End Sub
End Class
